  <!-- ======= Header ======= -->
  <header id="header" class="top header-scrolled">
    <div class="container d-flex align-items-center">

      <h1 class="logo mr-auto"><a href="index.php"><img src="<?= $us_url_root ?>users/images/logo.png"></a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo mr-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="#services">Services</a></li>
            <?php if(isset($user) && $user->isLoggedIn()){ ?>


            <?php }else{ ?>
                <li><a href="<?=$us_url_root?>users/login.php">Login</a></li>
                <li><a href="<?=$us_url_root?>users/join.php">Register</a></li>
            <?php } ?>
          <li class="drop-down"><a href="">More</a>
            <ul>
            <?php if(isset($user) && $user->isLoggedIn() && hasPerm([2], $user->data()->id)){ ?>
              <li class="drop-down"><a href="#">Admin</a>
                <ul>
                  <li><a href="<?=$us_url_root?>users/admin.php">Admin Dashboard</a></li>
                  <li><a href="<?=$us_url_root?>users/admin.php?view=users">User Management</a></li>
                  <li><a href="<?=$us_url_root?>users/admin.php?view=permissions">Permission Management</a></li>
                  <li><a href="<?=$us_url_root?>users/admin.php?view=pages">Page Management</a></li>
                  <li><a href="<?=$us_url_root?>users/admin.php?view=logs">Log Management</a></li>
                </ul>
              </li>
            <?php }else{ ?>
            
            <?php } ?>
            <?php if(isset($user) && $user->isLoggedIn()){ ?>
              <li><a href="<?=$us_url_root?>users/account.php">My Account</a></li>
              <li><a href="<?=$us_url_root?>users/logout.php">Logout</a></li>
            <?php }else{ ?>
              <li><a href="<?=$us_url_root?>support.php">Support</a></li>        
              <li><a href="<?=$us_url_root?>users/forgot_password.php">Forgot Password?</a></li>
            <?php } ?>
            </ul>
          </li>

        </ul>
      </nav><!-- .nav-menu -->

    <?php if(isset($user) && $user->isLoggedIn()){ ?>
      <a href="<?=$us_url_root?>users/account.php" class="get-started-btn">Dashboard</a>
    <?php }else{ ?>
      <a href="<?=$us_url_root?>users/login.php" class="get-started-btn">Get Started</a>
    <?php } ?>
    </div>
  </header><!-- End Header -->
<?php
    if(isset($_GET['err'])){
      err("<font color='red'>".$err."</font>");
    }

    if(isset($_GET['msg'])){
      err($msg);
    }
