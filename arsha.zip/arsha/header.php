<?php require_once($abs_us_root.$us_url_root.'users/includes/template/header1_must_include.php'); ?>

<!-- Bootstrap 3 Glyphicons for Compatibility Reasons -->
<?php require_once($abs_us_root.$us_url_root.'usersc/templates/'.$settings->template.'/assets/fonts/glyphicons.php'); ?>


<!-- Table Sorting and Such -->
<link href="<?=$us_url_root?>users/css/datatables.css" rel="stylesheet">

  <!-- Favicons -->
  <link href="<?=$us_url_root?>usersc/templates/<?=$settings->template?>/assets/img/favicon.png" rel="icon">
  <link href="<?=$us_url_root?>usersc/templates/<?=$settings->template?>/assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?=$us_url_root?>usersc/templates/<?=$settings->template?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?=$us_url_root?>usersc/templates/<?=$settings->template?>/assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="<?=$us_url_root?>usersc/templates/<?=$settings->template?>/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="<?=$us_url_root?>usersc/templates/<?=$settings->template?>/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="<?=$us_url_root?>usersc/templates/<?=$settings->template?>/assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="<?=$us_url_root?>usersc/templates/<?=$settings->template?>/assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="<?=$us_url_root?>usersc/templates/<?=$settings->template?>/assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?=$us_url_root?>usersc/templates/<?=$settings->template?>/assets/css/style.css" rel="stylesheet">

<!-- jQuery Fallback -->
<script type="text/javascript">
if (typeof jQuery == 'undefined') {
  document.write(unescape("%3Cscript src='<?=$us_url_root?>users/js/jquery.js' type='text/javascript'%3E%3C/script%3E"));
}
</script>

<?php
//optional
if(file_exists($abs_us_root.$us_url_root.'usersc/templates/'.$settings->template.'.css')){?> <link href="<?=$us_url_root?>usersc/templates/<?=$settings->template?>.css" rel="stylesheet"> <?php } ?>

</head>
<?php require_once($abs_us_root.$us_url_root.'users/includes/template/header3_must_include.php'); ?>
